
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Teste1 {
    public static void main(String[] args) {
        ArrayList<Aluno> lista = new ArrayList<>();
        
        int qtd = Integer.parseInt(JOptionPane.showInputDialog(null,"Quantos alunos?"));
        Util.popular(lista, qtd);
        //Util.exibir(lista);
        
        int matricula = Integer.parseInt(JOptionPane.showInputDialog(null,"Qual o número de matrícula a pesquisar?"));
        long tempoI, tempoF, tempoT;
        
        tempoI = System.currentTimeMillis();
        int posicao = Util.pesquisaSequencial(matricula,lista);
        tempoF = System.currentTimeMillis();
        tempoT = tempoF - tempoI;
        
        JOptionPane.showMessageDialog(null,"Matricula na posição: " + posicao +
                "\nTempo de processamento sequencial: " + tempoT + " ms");
        
        //-------------------
        
        tempoI = System.currentTimeMillis();
        posicao = Util.pesquisaBinaria(matricula,lista);
        tempoF = System.currentTimeMillis();
        tempoT = tempoF - tempoI;
        
        JOptionPane.showMessageDialog(null,"Matricula na posição: " + posicao +
                "\nTempo de processamento binaria: " + tempoT + " ms");
        
        System.exit(0);
    }
    
}
