
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Principal {
    public static void main(String[] args) {
        ArrayList<Aluno> listaBolha = new ArrayList();
        ArrayList<Aluno> listaSelecao = new ArrayList();
        ArrayList<Aluno> listaInsercao = new ArrayList();
        int qtd = Integer.parseInt(JOptionPane.showInputDialog(null, "Quantos numeros?"));
        
        Ordenacao.popularLista(listaBolha, qtd);
        listaSelecao.addAll(listaBolha);
        listaInsercao.addAll(listaBolha);
        
        Ordenacao.bolha(listaBolha);
        Ordenacao.exibirLista(listaBolha);
        Ordenacao.selecao(listaSelecao);
        Ordenacao.exibirLista(listaSelecao);
        Ordenacao.insercao(listaInsercao);
        Ordenacao.exibirLista(listaInsercao);
        
        System.exit(0);
    }
    
}
