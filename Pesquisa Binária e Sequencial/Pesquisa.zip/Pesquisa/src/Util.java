
import java.util.ArrayList;


public class Util {
    public static void popular(ArrayList<Aluno> lista, int qtd) {
        for (int i = 0; i < qtd; i++) {
            lista.add(new Aluno(i));
        }
    }
    
    public static void exibir(ArrayList<Aluno> lista) {
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i).matricula);
        }
    }
    
    public static int pesquisaSequencial(int matricula, ArrayList<Aluno> lista) {
       for (int i = 0; i < lista.size(); i++) {
           if (matricula == lista.get(i).matricula)
               return i;
       } 
       return -1; //nao localizado
    }
    
    public static int pesquisaBinaria(int matricula, ArrayList<Aluno> lista) {
       int ini = 0, fim = lista.size() - 1, meio;
       int comparacoes = 0;
       while (ini <= fim) {
           meio = (int)(ini+fim)/2;
           comparacoes++;
           if (matricula == lista.get(meio).matricula) {
               System.out.println("Comparacoes: " + comparacoes);
               return meio;
           }
           if (matricula < lista.get(meio).matricula){
               fim = meio - 1; //ir para esquerda
           } else { //ir para direita
               ini = meio + 1;
           }
       }
       System.out.println("Comparacoes: " + comparacoes);
       return -1; //nao localizado
    }
}
