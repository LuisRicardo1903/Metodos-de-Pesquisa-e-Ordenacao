public class Aluno {
    int matricula;
    String nome;

    public Aluno(int matricula, String nome) {
        this.matricula = matricula;
        this.nome = nome;
    }
    
    public Aluno(int matricula) {
        this.matricula = matricula;
    }  

    @Override
    public String toString() {
        return this.matricula + " - " + this.nome;
    }    
}